//
//  EnumSegmentController.swift
//  TestTask
//
//  Created by Владимир Колосов on 24.05.2021.
//

import Foundation

enum EnumSegmentControllerl {
    case From
    case To
}
