//
//  RxError.swift
//  VovaFinal
//
//  Created by Владимир Колосов on 02.04.2021.
//

import Foundation

struct RxError: Error {
    let message: String
}
